module.exports={
    DB:"mongodb://localhost:27017/pizzadb"
    //mongodb://localhost:27017/mastekdb -> connection string
    // : indicates the driver to which the connection hsas to be done
};