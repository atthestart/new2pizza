import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PizzaService } from 'src/app/pizza.service';

@Component({
  selector: 'app-admin-delete',
  templateUrl: './admin-delete.component.html',
  styleUrls: ['./admin-delete.component.css']
})
export class AdminDeleteComponent implements OnInit {
  constructor(private route:ActivatedRoute,private service:PizzaService) { }
  ngOnInit() {
   let pid=this.route.snapshot.paramMap.get("pid");
   this.deleteAPizza(pid);
  }
  deleteAPizza(pid){
      this.service.deleteAPizza(pid);
  }

}
