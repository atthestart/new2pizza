import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizzashop',
  templateUrl: './pizzashop.component.html',
  styleUrls: ['./pizzashop.component.css']
})
export class PizzashopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
