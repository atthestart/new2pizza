export class Pizza{
    _id?:number;
    pid:number;
    name : String;
    price : number;
    _v?:number;
}